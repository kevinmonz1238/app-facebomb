import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TiendaPage } from './tienda.page';
import { IonicModule } from '@ionic/angular';
import { RouterTestingModule } from '@angular/router/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { FirebaseTestingModule } from 'src/testing/firebase-testing.module';

describe('TiendaPage', () => {
  let component: TiendaPage;
  let fixture: ComponentFixture<TiendaPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TiendaPage],
      imports: [
        CommonModule,
        IonicModule.forRoot(),
        RouterTestingModule,
        HttpClientTestingModule,
        ...FirebaseTestingModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(TiendaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
