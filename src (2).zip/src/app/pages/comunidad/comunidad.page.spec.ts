import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ComunidadPage } from './comunidad.page';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { FirebaseTestingModule } from 'src/testing/firebase-testing.module';

describe('ComunidadPage', () => {
  let component: ComunidadPage;
  let fixture: ComponentFixture<ComunidadPage>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ComunidadPage],
      imports: [
        CommonModule,
        IonicModule.forRoot(),
        ...FirebaseTestingModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();

    fixture = TestBed.createComponent(ComunidadPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
