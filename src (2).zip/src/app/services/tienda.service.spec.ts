import { TestBed } from '@angular/core/testing';
import { TiendaService } from './tienda.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { FirebaseTestingModule } from 'src/testing/firebase-testing.module';

describe('TiendaService', () => {
  let service: TiendaService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        ...FirebaseTestingModule
      ],
      providers: [TiendaService]
    });

    service = TestBed.inject(TiendaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
