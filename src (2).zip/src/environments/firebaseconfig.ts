export const firebaseConfig = {
  apiKey: "AIzaSyBTY26cYGGKdL6sQs4VmPKp5PJ7vK4UyzE",
  authDomain: "app-facebomb.firebaseapp.com",
  databaseURL: "https://app-facebomb-default-rtdb.firebaseio.com",
  projectId: "app-facebomb",
  storageBucket: "app-facebomb.firebasestorage.app",
  messagingSenderId: "1019503271707",
  appId: "1:1019503271707:web:1d5ddb76bd9ff005e6fdbe",
  measurementId: "G-WYF4QN0FQ3"
};